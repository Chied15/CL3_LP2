function buscar(id){
	$.ajax({
		url:'PacienteServlet',
		type:'POST',
		data:{
			accion:"buscar",
			idPaciente:id
		},
		success: function(respuestaJson){
			$('#txtIdPaciente').val(respuestaJson.idPaciente);
			$('#cboCita').val(respuestaJson.idCita);
			$('#txtDni').val(respuestaJson.dni);
			$('#txtApePaterno').val(respuestaJson.apePaterno);
			$('#txtApeMaterno').val(respuestaJson.apeMaterno);
			$('#txtNombre').val(respuestaJson.nombres);
		}
	});
	listarCitas();
}


$(function() {
	
	listar();
	
	$("#formPaciente").bind("submit",function(){
		guardar();
	});
	
	function guardar(){	
		$.ajax({
			url:'PacienteServlet',
			type:'POST',
			data:{
				accion:"guardar",
				idPaciente:$('#txtIdPaciente').val(),
				idCita:$('#cboCita').val(),
				dni:$('#txtDni').val(),
				apePaterno:$('#txtApePaterno').val(),
				apeMaterno:$('#txtApeMaterno').val(),
				nombres:$('#txtNombre').val()
			},
			success:function(responseText){
				alert("Se guardaron los datos correctamente");
			}
		});
	}	
	
	function listar(){
		$.ajax({
			url:'PacienteServlet',
			data:{
				accion:"listar"
			},
			type:'GET',
			dataType:'json',
			success:function(respuestaJson){
				for(var i in respuestaJson){
					var paciente = respuestaJson[i];
					$("#tablaPacientes tbody").append(
						"<tr>"
							+"<td>"+paciente.idPaciente+"</td>"
							+"<td>"+cita.numCita+"</td>"
							+"<td>"+paciente.idCita+"</td>"
							+"<td>"+paciente.apePaterno+"</td>"
							+"<td>"+paciente.apeMaterno+"</td>"
							+"<td>"+paciente.nombres+"</td>"
							+"<td>"+
							 "<button type='button' class='btn btn-warning' data-toggle='modal' data-target='#myModal' id='btnEditar' onclick='buscar("+paciente.idPaciente+");'>EDITAR</button>"
						+"</tr>"	
					);
				}
			}
		});
	}
})

function listarCitas(){
	$.ajax({
		url:'CitaServlet',
		data:{
			accion:"listar"
		},
		type:'GET',
		dataType:'json',
		success: function(respuestaJson){
			var idCitaHidden= $('#cboCitaHidden').val();
			
			for(var i in respuestaJson){
				var cita = respuestaJson[i];
				var strSelected = (cita.idCita === idCitaHidden)?" selected ":"";
				
				$("#cboCita").append(
					"<option id='"+cita.idCita+"'"+strSelected+">" + cita.numCita +
					"</option>"
				);
			}
		}
	});
}
