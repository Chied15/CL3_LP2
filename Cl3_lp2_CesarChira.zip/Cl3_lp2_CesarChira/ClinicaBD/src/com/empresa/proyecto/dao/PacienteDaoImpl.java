package com.empresa.proyecto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.empresa.proyecto.bean.Paciente;
import com.empresa.proyecto.util.JDBCUtil;

public class PacienteDaoImpl implements IPacienteDao {

	public JDBCUtil db;
	
	public PacienteDaoImpl() {
		this.db = new JDBCUtil();
	}

	@Override
	public List<Paciente> list() throws Exception{
		List<Paciente> list = null;
		String strSql = "select p.id_Paciente,p.id_Cita,p.dni,p.apePaterno,p.apeMaterno,p.nombres from tb_paciente p";
		System.out.println("strSql: "+strSql);
		try {
			Connection cn = db.getConexion();
			PreparedStatement st = cn.prepareStatement(strSql);
			ResultSet rs = st.executeQuery();
			list = new ArrayList<Paciente>();
			while (rs.next()) {
				Paciente paciente = new Paciente();
				paciente.setIdPaciente(rs.getInt("id_Paciente"));
				paciente.setIdCita(rs.getInt("id_Cita"));
				paciente.setDni(rs.getString("dni"));
				paciente.setApePaterno(rs.getString("apePaterno"));
				paciente.setApeMaterno(rs.getString("apeMaterno"));
				paciente.setNombres(rs.getString("nombres"));
				list.add(paciente);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public int insert(Paciente paciente) {
		int numRes = 0;
		String strSql = "INSERT INTO tb_paciente (id_Cita,dni,apePaterno,apeMaterno,nombres) values"
						+ "("
						+ paciente.getIdCita()+","
						+ "'"+paciente.getDni()+"',"
						+ "'"+paciente.getApePaterno()+"',"
						+ "'"+paciente.getApeMaterno()+"',"
						+ "'"+paciente.getNombres()+"'"
						+ ")";
		System.out.println("strSql: "+strSql);
		try {
			Connection cn = db.getConexion();
			PreparedStatement st = cn.prepareStatement(strSql);
			numRes = st.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return numRes;
	}

	@Override
	public int update(Paciente paciente) throws Exception {
		int numRes = 0;
		String strSql = " UPDATE tb_paciente SET"
					  + " id_Cita = "+paciente.getIdCita()+","
					  + " dni = '"+paciente.getDni()+"',"
					  + " apePaterno = '"+paciente.getApePaterno()+"',"
					  + " apeMaterno = '"+paciente.getApeMaterno()+"',"
					  + " nombres = '"+paciente.getNombres()+"'"
					  + " WHERE id_Paciente = "+paciente.getIdPaciente();
		System.out.println("strSql: "+strSql);
		try {
			Connection cn = db.getConexion();
			PreparedStatement st = cn.prepareStatement(strSql);
			numRes = st.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return numRes;
	}

	@Override
	public Paciente find(Paciente paciente) throws Exception {
		
		String strSql = " select p.id_Paciente,p.id_Cita,p.dni,p.apePaterno,p.apeMaterno,p.nombres from tb_paciente p"
					  + " where p.id_Paciente = "+paciente.getIdPaciente();
		System.out.println("strSql: "+strSql);
		Paciente pac = new Paciente();
		try {
			Connection cn = db.getConexion();
			PreparedStatement st = cn.prepareStatement(strSql);
			ResultSet rs = st.executeQuery();
			
			while (rs.next()) {
				pac.setIdPaciente(rs.getInt("id_Paciente"));
				pac.setIdCita(rs.getInt("id_Cita"));
				pac.setDni(rs.getString("dni"));
				pac.setApePaterno(rs.getString("apePaterno"));
				pac.setApeMaterno(rs.getString("apeMaterno"));
				pac.setNombres(rs.getString("nombres"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pac;
	}
	
	
}
