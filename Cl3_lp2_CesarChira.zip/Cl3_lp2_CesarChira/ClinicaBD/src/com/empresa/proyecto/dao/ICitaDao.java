package com.empresa.proyecto.dao;

import java.util.List;

import com.empresa.proyecto.bean.Cita;

public interface ICitaDao {
	
	List<Cita> list() throws Exception;
}
