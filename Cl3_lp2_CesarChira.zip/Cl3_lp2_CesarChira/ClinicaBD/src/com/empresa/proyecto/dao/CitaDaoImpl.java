package com.empresa.proyecto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.empresa.proyecto.bean.Cita;
import com.empresa.proyecto.util.JDBCUtil;

public class CitaDaoImpl implements ICitaDao {

	public JDBCUtil db;
	
	public CitaDaoImpl() {
		this.db = new JDBCUtil();
	}
	
	@Override
	public List<Cita> list() throws Exception {
		List<Cita> list = null;
		String strSql = "select c.id_Cita,c.numCita from tb_cita c";
		System.out.println("strSql: "+strSql);
		try {
			Connection cn = db.getConexion();
			PreparedStatement st = cn.prepareStatement(strSql);
			ResultSet rs = st.executeQuery();
			list = new ArrayList<>();
			while (rs.next()) {
				Cita cita = new Cita();
				cita.setIdCita(rs.getInt("id_Cita"));
				cita.setNumCita(rs.getString("c.numCita"));
				list.add(cita);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}
