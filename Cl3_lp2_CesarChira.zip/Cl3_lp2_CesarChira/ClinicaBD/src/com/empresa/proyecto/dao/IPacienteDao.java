package com.empresa.proyecto.dao;

import java.util.List;

import com.empresa.proyecto.bean.Paciente;

public interface IPacienteDao {
	List<Paciente> list() throws Exception;
	
	int insert(Paciente paciente) throws Exception;
	
	int update(Paciente paciente) throws Exception;

	Paciente find(Paciente paciente) throws Exception;
}
