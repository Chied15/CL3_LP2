package com.empresa.proyecto.bean;

public class Cita {
	
	private int idCita;
	private String numCita;
	
	public Cita() {
	}

	public int getIdCita() {
		return idCita;
	}

	public void setIdCita(int idCita) {
		this.idCita = idCita;
	}

	public String getNumCita() {
		return numCita;
	}

	public void setNumCita(String numCita) {
		this.numCita = numCita;
	}
}
