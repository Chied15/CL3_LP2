package com.empresa.proyecto.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.empresa.proyecto.bean.Cita;
import com.empresa.proyecto.service.CitaServiceImpl;
import com.empresa.proyecto.service.ICitaService;
import com.google.gson.Gson;

@WebServlet("/CitaServlet")
public class CitaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public final ICitaService citaService;

    public CitaServlet() {
        System.out.println("---------------------------");
        System.out.println("Ingresando a CitaServlet");
        citaService = new CitaServiceImpl();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String strAccion = request.getParameter("accion");
		System.out.println("strAccion: "+strAccion);
		switch (strAccion) {
		case "listar":
			listarCita(request,response);
			break;
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void listarCita(HttpServletRequest request, HttpServletResponse response) {
		try {
			// 1. Convertir java a JSON
			Gson gson = new Gson();
			List<Cita> listCitas = 		citaService.listar();
			String cadenaJson = gson.toJson(listCitas);
			
			// 2. Devolver JSON en el response
			response.setContentType("application/json");
			response.getWriter().write(cadenaJson);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
