package com.empresa.proyecto.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.empresa.proyecto.bean.Paciente;
import com.empresa.proyecto.service.PacienteServiceImpl;
import com.empresa.proyecto.service.IPacienteService;
import com.google.gson.Gson;

@WebServlet("/PacienteServlet")
public class PacienteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public final IPacienteService pacienteService;

	static List<Paciente> listPacientes = new ArrayList<>();

	public PacienteServlet() {
		System.out.println("-----------------------");
		System.out.println("Entrando a PacienteServlet...");
		pacienteService = new PacienteServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String strAccion = request.getParameter("accion");
		System.out.println("strAccion: " + strAccion);
		switch (strAccion) {
		case "listar":
			listarPacientes(request, response);
			break;
		case "guardar":
			guardarPacientes(request, response);
			break;
		case "buscar":
			buscarPacientes(request, response);
			break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	private void listarPacientes(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("-------------------------------------------");
		System.out.println("Ingresando al m�todo listarPacientes...");
		
		try {
			// 1. Convertir a JSON
			Gson gson = new Gson();
			List<Paciente> listPacientes = pacienteService.listar();
			String cadenaJson = gson.toJson(listPacientes);
			
			// 2. Enviar en el response la cadena JSON
			response.setContentType("application/json");
			response.getWriter().write(cadenaJson);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void guardarPacientes(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("-------------------------------------------");
		System.out.println("Ingresando al m�todo guardarPacientes...");
		try {
			Paciente paciente = new Paciente();
			paciente.setIdPaciente(Integer.parseInt(request.getParameter("idPaciente")));
			paciente.setIdCita(Integer.parseInt(request.getParameter("idCita")));
			paciente.setDni(request.getParameter("dni"));
			paciente.setApePaterno(request.getParameter("apePaterno"));
			paciente.setApeMaterno(request.getParameter("apeMaterno"));
			paciente.setNombres(request.getParameter("nombres"));
			pacienteService.guardar(paciente);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private void buscarPacientes(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Ingresando al metodo buscarFuncionario...");
		try {
			int idPaciente = Integer.parseInt(request.getParameter("idPaciente"));
			System.out.println("idPaciente: "+idPaciente);
			String cadenaJson = "";
			Gson gson = new Gson();
			Paciente pacienteEdit = new Paciente();
			pacienteEdit.setIdPaciente(idPaciente);
			Paciente paciente = pacienteService.buscar(pacienteEdit);
			cadenaJson = gson.toJson(paciente);
			
			response.setContentType("application/Json");
			response.getWriter().write(cadenaJson);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
