package com.empresa.proyecto.service;

import java.util.List;

import com.empresa.proyecto.bean.Paciente;
import com.empresa.proyecto.dao.PacienteDaoImpl;
import com.empresa.proyecto.dao.IPacienteDao;

public class PacienteServiceImpl implements IPacienteService{
	
	private IPacienteDao dao;
	
	public PacienteServiceImpl() {
		dao = new PacienteDaoImpl();
	}

	@Override
	public List<Paciente> listar() throws Exception {
		return dao.list();
	}

	@Override
	public int guardar(Paciente paciente) throws Exception {
		if (paciente.getIdPaciente()<1) {
			return dao.insert(paciente);
		}else {
			return dao.update(paciente);
		}
	}

	@Override
	public Paciente buscar(Paciente pacienteEdit) throws Exception {
		return dao.find(pacienteEdit);
	}
}
