package com.empresa.proyecto.service;

import java.util.List;

import com.empresa.proyecto.bean.Cita;

public interface ICitaService {
	List<Cita> listar() throws Exception;
}
