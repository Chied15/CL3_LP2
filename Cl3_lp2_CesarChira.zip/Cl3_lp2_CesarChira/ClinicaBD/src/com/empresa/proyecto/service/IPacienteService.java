package com.empresa.proyecto.service;

import java.util.List;

import com.empresa.proyecto.bean.Paciente;

public interface IPacienteService {

	List<Paciente> listar() throws Exception;
	
	int guardar(Paciente paciente) throws Exception;

	Paciente buscar(Paciente pacienteEdit) throws Exception;
}
