package com.empresa.proyecto.service;

import java.util.List;

import com.empresa.proyecto.bean.Cita;
import com.empresa.proyecto.dao.CitaDaoImpl;
import com.empresa.proyecto.dao.ICitaDao;

public class CitaServiceImpl  implements ICitaService{
	
	private ICitaDao dao;
	
	public CitaServiceImpl() {
		dao = new CitaDaoImpl();
	}

	@Override
	public List<Cita> listar() throws Exception {
		return dao.list();
	}

}
