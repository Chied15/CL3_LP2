package com.empresa.proyecto.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.cj.jdbc.DatabaseMetaData;

public class JDBCUtil {
	
	String ConxBD = "jdbc:mysql://mysql5006.site4now.net:3306/clinibd?serverTimezone=America/Lima";
	String JdbcBD = "com.mysql.cj.jdbc.Driver";
	
	String UserBD = "a57036_clinibd";
	String PassBD = "Q9arvasy";
	
	Connection Conexion;
	
	public JDBCUtil() {
		try {
			Class.forName(JdbcBD);
			Conexion = DriverManager.getConnection(ConxBD,UserBD,PassBD);
			if (Conexion != null) {
				DatabaseMetaData dm = (DatabaseMetaData) Conexion.getMetaData();
				System.out.println("Driver name: "+dm.getDriverName());
				System.out.println("Driver version: "+dm.getDriverVersion());
				System.out.println("Product name: "+dm.getDatabaseProductName());
				System.out.println("Driver version: "+dm.getDatabaseProductVersion());
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	
	public Connection getConexion() {
		return this.Conexion;
	}
}
