create database clinibd;

use clinibd;

CREATE TABLE tb_cita(
    id_Cita INT PRIMARY KEY,
    numCita VARCHAR(100) NOT NULL
); CREATE TABLE tb_paciente(
    id_Paciente INT PRIMARY KEY,
    id_Cita INT,
    dni VARCHAR(8),
    apePaterno VARCHAR(100),
    apeMaterno VARCHAR(100),
    nombres VARCHAR(100),
    CONSTRAINT FK_NUM_CITA FOREIGN KEY(id_Cita) REFERENCES tb_cita(id_Cita)
); INSERT INTO tb_cita
VALUES(1, 'a-01');
INSERT INTO tb_cita
VALUES(2, 'a-02');
INSERT INTO tb_cita
VALUES(3, 'a-03');
SELECT
    *
FROM
    tb_cita;
INSERT INTO tb_paciente
VALUES(
    1,
    1,
    '71477325',
    'chira',
    'cossio',
    'Cesar'
);
INSERT INTO tb_paciente
VALUES(2, 2, '71477326', 'chira', 'cossio', 'Rosa');